//main.js

exports.handler = async (event) => {
    console.log(event)

    return {
        body:"xd"
    }
}